from django.apps import AppConfig


class MydeskConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "myDesk"
